const CAPTURE_BUFFER_DURATION_SECONDS = 0.08
const RENDER_QUANTUM_FRAME_COUNT = 128

class MemexAudioRecorderProcessor extends AudioWorkletProcessor {
    constructor() {
        super()
        this.bufferFrameCount = Math.max(
            RENDER_QUANTUM_FRAME_COUNT,
            Math.ceil(
                (sampleRate * CAPTURE_BUFFER_DURATION_SECONDS) /
                    RENDER_QUANTUM_FRAME_COUNT,
            ) * RENDER_QUANTUM_FRAME_COUNT,
        )
        this.samples = new Float32Array(this.bufferFrameCount)
        this.frameCount = 0
        this.sumSquares = 0
        this.isRecording = true
        this.port.onmessage = (event) => {
            if (event.data && event.data.type === 'setRecording') {
                this.isRecording = event.data.isRecording === true
            }
            if (event.data && event.data.type === 'flush') {
                this.flush()
            }
        }
    }

    flush() {
        if (this.frameCount === 0) {
            return
        }
        const samples =
            this.frameCount === this.samples.length
                ? this.samples
                : this.samples.slice(0, this.frameCount)
        const level = Math.sqrt(this.sumSquares / this.frameCount)
        this.port.postMessage(
            {
                type: 'pcm',
                samples: samples.buffer,
                sampleRate,
                level,
            },
            [samples.buffer],
        )
        this.samples = new Float32Array(this.bufferFrameCount)
        this.frameCount = 0
        this.sumSquares = 0
    }

    process(inputs) {
        const input = inputs[0]
        const channel = input && input[0]
        if (!channel || !this.isRecording) {
            return true
        }
        for (let index = 0; index < channel.length; index += 1) {
            const sample = channel[index]
            this.samples[this.frameCount] = sample
            this.frameCount += 1
            this.sumSquares += sample * sample
            if (this.frameCount === this.bufferFrameCount) {
                this.flush()
            }
        }
        return true
    }
}

registerProcessor('memex-audio-recorder-processor', MemexAudioRecorderProcessor)
