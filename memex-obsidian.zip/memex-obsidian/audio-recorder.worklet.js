class MemexAudioRecorderProcessor extends AudioWorkletProcessor {
    constructor() {
        super()
        this.buffers = []
        this.frameCount = 0
        this.sumSquares = 0
        this.levelSampleCount = 0
        this.isRecording = true
        this.port.onmessage = (event) => {
            if (event.data && event.data.type === 'setRecording') {
                this.isRecording = event.data.isRecording === true
            }
            if (event.data && event.data.type === 'flush') {
                this.flush()
            }
        }
    }

    flush() {
        if (this.frameCount === 0) {
            return
        }
        const samples = new Float32Array(this.frameCount)
        let offset = 0
        for (const buffer of this.buffers) {
            samples.set(buffer, offset)
            offset += buffer.length
        }
        const level =
            this.levelSampleCount > 0
                ? Math.sqrt(this.sumSquares / this.levelSampleCount)
                : 0
        this.port.postMessage(
            {
                type: 'pcm',
                samples: samples.buffer,
                sampleRate,
                level,
            },
            [samples.buffer],
        )
        this.buffers = []
        this.frameCount = 0
        this.sumSquares = 0
        this.levelSampleCount = 0
    }

    process(inputs) {
        const input = inputs[0]
        const channel = input && input[0]
        if (!channel || !this.isRecording) {
            return true
        }
        const copy = new Float32Array(channel.length)
        copy.set(channel)
        this.buffers.push(copy)
        this.frameCount += copy.length
        for (let index = 0; index < channel.length; index += 1) {
            const sample = channel[index]
            this.sumSquares += sample * sample
        }
        this.levelSampleCount += channel.length
        if (this.frameCount >= 2048) {
            this.flush()
        }
        return true
    }
}

registerProcessor('memex-audio-recorder-processor', MemexAudioRecorderProcessor)
